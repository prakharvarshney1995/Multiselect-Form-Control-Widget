// JavaScript Document
demo.controller('DemoController',  function($scope, $location) {

	$scope.demoOptions = {
		labelAll: 'Available :',
		labelSelected: 'Selected :',
		items: [{'id': '50', 'name': '0 - 24'}, {'id': '45', 'name': '25 - 99'}, {'id': '66', 'name': '50 - 99'}, {'id': '30', 'name' : '100 - 249' }, {'id': '41', 'name': '250 - 499' }, {'id': '34', 'name': '1000 - 4999'}, {'id': '24', 'name': '5000 - 9999'}, {'id': '14', 'name': '10000 - 49999'}, {'id': '04', 'name': '50000 - 100000'}, {'id': '20', 'name': '>100000'}],
		selectedItems: [] 
	};

});